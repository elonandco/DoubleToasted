<?php

// This script
echo '<h1>Generate a shitload of posts</h1>';

// Access db connection
global $wpdb;
require_once("../../../wp-load.php");
require_once('../../../wp-includes/class-phpass.php');

// Start at ID:
$i = 3571; // Will not match the post ID

// Episode Metadata
$ep = 10;

// Loop thru each ID - 300
while ($i <= 3573) {

	$currentTime = date("Y-m-d H:i:s");
	$gmtTime = gmdate("Y-m-d H:i:s");

	$addpost = array(
	  'post_content'   => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec mollis. Quisque convallis libero in sapien pharetra tincidunt. Aliquam elit ante, malesuada id, tempor eu, gravida id, odio. Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna. Praesent sit amet ligula id orci venenatis auctor. Phasellus porttitor, metus non tincidunt dapibus, orci pede pretium neque, sit amet adipiscing ipsum lectus et libero. Aenean bibendum. Curabitur mattis quam id urna. Vivamus dui. Donec nonummy lacinia lorem. Cras risus arcu, sodales ac, ultrices ac, mollis quis, justo. Sed a libero. Quisque risus erat, posuere at, tristique non, lacinia quis, eros.', // The full text of the post.
	  'post_name'      => 'test-post-title-number-', // The name (slug) for your post
	  'post_title'     => 'Test Post Title Number ', // The title of your post.
	  'post_status'    => 'publish', // Default 'draft'.
	  'post_type'      => 'dt_shows', // Default 'post'.
//	  'post_author'    => 1, // The user ID number of the author. Default is the current user ID.
// 	  'ping_status'    => [ 'closed' ], // Pingbacks or trackbacks allowed. Default is the option 'default_ping_status'.
//	  'post_parent'    => 0, // Sets the parent of the new post, if any. Default 0.
// 	  'menu_order'     => [ 0 ], // If new post is a page, sets the order in which it should appear in supported menus. Default 0.
// 	  'post_date'      => [ $currentTime ], // The time post was made.
// 	  'post_date_gmt'  => [ $gmtTime ], // The time post was made, in GMT.
// 	  'comment_status' => [ 'open' ], // Default is the option 'default_comment_status', or 'closed'.
// 	  //'post_category'  => [ array(190, 191) ], // Default empty.
//	  'tax_input'      => array( 'shows' => array(190, 191) ) // For custom taxonomies. Default empty.
	);  
	
	//wp_insert_post( $addpost );
	
// This script should be run seperately, once you know the ID to start from (differs from $i)
	add_post_meta( $i, '_lac0509_dt_show_episode', $ep );
	update_post_meta( $i, '_thumbnail_id', 1733 );

// Used to fix my db fuckup!
//	delete_post_meta($i, '_lac0509_dt_show_episode');

	$ep++;	
	$i++;	
	
	echo 'Just finished with post ' . $i;
	
}



return;

?>