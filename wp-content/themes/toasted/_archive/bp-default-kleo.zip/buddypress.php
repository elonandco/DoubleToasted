<?php
/**
 * The template for displaying Buddypress pages
 *
 *
 * @package Wordpress
 * @subpackage Kleo
 * @since Kleo 1.0
 */

get_header(); ?>

<?php get_template_part('page-parts/general-before-wrap'); ?>

<?php
if ( have_posts() ) :

	// Start the Loop.
	while ( have_posts() ) : the_post(); 
	
	?>
	
	<div class="row">
		<div class="col-sm-12">
			
			<h1 class="text-center" style="font-size:20px;"><?php echo strip_tags($title); ?></h1>
			
			<div class="article-content">
					<?php the_content(); ?>
			</div><!--end article-content-->
		</div><!--end twelve-->
	</div>


	<?php
	endwhile;

endif;
?>
        
<?php get_template_part('page-parts/general-after-wrap'); ?>

<?php get_footer(); ?>