<?php get_header(); ?>

<div class="index main">

	<div class="content">	

	<?php if ( have_posts() ) : ?>

		<?php while ( have_posts() ) : the_post(); ?>

					<?php the_content(); ?>

		<?php endwhile; ?>

	<?php endif; ?>
	
	</div>
	
</div>

<?php wp_enqueue_script( 'bp-ajax', get_template_directory_uri() . '/buddypress/js/buddypress.js', 'pound-basic-scripts-0507', '1.0.0', true ); ?>

<?php get_footer(); ?>